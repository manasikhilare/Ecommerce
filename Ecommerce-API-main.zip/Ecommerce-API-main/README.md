# Ecommerce-API
Ecommerce API project for coding ninjas assignment


To use the API simply clone the repo in your local machine and run
npm i
then run
npm start
